echo "Installing phantom device drivers"
dpkg -i "OpenHapticsAE_Linux_v3_0/PHANTOM Device Drivers/64-bit/phantomdevicedrivers_4.3-3_amd64.deb"

echo "Installing OpenHaptics"
dpkg -i "OpenHapticsAE_Linux_v3_0/OpenHaptics-AE 3.0/64-bit/openhaptics-ae_3.0-2_amd64.deb"

apt-get install libglw1-mesa libmotif4
sh -c 'echo "/usr/lib64" > /etc/ld.so.conf.d/lib64.conf'

echo "Copying needed libraries for 3.x kernel"
cp JUJU/libPHANToMIO.so JUJU/libPHANToMIO.so.4.3 /usr/lib64/
cp JUJU/PHANToMConfiguration /usr/sbin
ldconfig

chmod 777 /dev/fw*
echo "****************************************************"
echo "Remember you should always type"
echo "chmod 777 /dev/fw*"
echo "to open permissions for the device."
echo "****************************************************"
